"""
Performance testing module for CSUbatch
"""

from .test_runner import run_performance_test

__all__ = ['run_performance_test']
